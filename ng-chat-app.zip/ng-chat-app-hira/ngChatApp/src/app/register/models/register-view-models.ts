export interface RegisterForm {
    screenName: string;
    selectedChatRoom: string;
  }