export interface Chat{
message:string,
timeStamp: Date,
chatRoom:string,
screenName:string

}